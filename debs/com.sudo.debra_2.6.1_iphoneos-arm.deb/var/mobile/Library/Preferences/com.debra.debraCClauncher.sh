#!/bin/bash

## Launch Filza to Debra directory
filzafile=/Applications/Filza.app/Filza
debradir=/var/mobile/Documents/Debra
if [ -f "${filzafile}" ]; then
    dtf "${debradir}"
else
    :
fi