#!/bin/bash
ATRECORDS="/var/mobile/Library/AutoTouch/Scripts/Records"
find "$ATRECORDS" -type f -a \( -name "*.js" \) -a -exec sed -i -e 's/\//-/g' {} +
find "$ATRECORDS" -type f -a \( -name "*.js" \) -a -exec sed -i '/const/d' {} +
for f in "$ATRECORDS"/*.js; do mv -- "$f" "${f%.js}.lua"; done
